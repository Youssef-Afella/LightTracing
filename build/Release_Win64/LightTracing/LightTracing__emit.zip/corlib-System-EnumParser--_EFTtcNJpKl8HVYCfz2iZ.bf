public static Result<T> Parse(StringView str, bool ignoreCase = false)
{
	if (str.IsEmpty)
		return .Err;
	return .Err;
}
