#pragma warning disable
public static function System.Platform.BfpFile*(char8* name, System.Platform.BfpFileCreateKind createKind, System.Platform.BfpFileCreateFlags createFlags, System.Platform.BfpFileAttributes createdFileAttrs, System.Platform.BfpFileResult* outResult) sBfpFile_Create;
public static System.Platform.BfpFile* BfpFile_Create(char8* name, System.Platform.BfpFileCreateKind createKind, System.Platform.BfpFileCreateFlags createFlags, System.Platform.BfpFileAttributes createdFileAttrs, System.Platform.BfpFileResult* outResult)
{
	if (sBfpFile_Create != null)
		return sBfpFile_Create(name, createKind, createFlags, createdFileAttrs, outResult);
	return System.Platform.BfpFile_Create(name, createKind, createFlags, createdFileAttrs, outResult);
}

public static function System.Platform.BfpFile*(System.Platform.BfpFileStdKind kind, System.Platform.BfpFileResult* outResult) sBfpFile_GetStd;
public static System.Platform.BfpFile* BfpFile_GetStd(System.Platform.BfpFileStdKind kind, System.Platform.BfpFileResult* outResult)
{
	if (sBfpFile_GetStd != null)
		return sBfpFile_GetStd(kind, outResult);
	return System.Platform.BfpFile_GetStd(kind, outResult);
}

public static function int(System.Platform.BfpFile* file) sBfpFile_GetSystemHandle;
public static int BfpFile_GetSystemHandle(System.Platform.BfpFile* file)
{
	if (sBfpFile_GetSystemHandle != null)
		return sBfpFile_GetSystemHandle(file);
	return System.Platform.BfpFile_GetSystemHandle(file);
}

public static function void(System.Platform.BfpFile* file) sBfpFile_Release;
public static void BfpFile_Release(System.Platform.BfpFile* file)
{
	if (sBfpFile_Release != null)
		return sBfpFile_Release(file);
	return System.Platform.BfpFile_Release(file);
}

public static function int(System.Platform.BfpFile* file, void* buffer, int size, int timeoutMS, System.Platform.BfpFileResult* outResult) sBfpFile_Write;
public static int BfpFile_Write(System.Platform.BfpFile* file, void* buffer, int size, int timeoutMS, System.Platform.BfpFileResult* outResult)
{
	if (sBfpFile_Write != null)
		return sBfpFile_Write(file, buffer, size, timeoutMS, outResult);
	return System.Platform.BfpFile_Write(file, buffer, size, timeoutMS, outResult);
}

public static function int(System.Platform.BfpFile* file, void* buffer, int size, int timeoutMS, System.Platform.BfpFileResult* outResult) sBfpFile_Read;
public static int BfpFile_Read(System.Platform.BfpFile* file, void* buffer, int size, int timeoutMS, System.Platform.BfpFileResult* outResult)
{
	if (sBfpFile_Read != null)
		return sBfpFile_Read(file, buffer, size, timeoutMS, outResult);
	return System.Platform.BfpFile_Read(file, buffer, size, timeoutMS, outResult);
}

public static function void(System.Platform.BfpFile* file) sBfpFile_Flush;
public static void BfpFile_Flush(System.Platform.BfpFile* file)
{
	if (sBfpFile_Flush != null)
		return sBfpFile_Flush(file);
	return System.Platform.BfpFile_Flush(file);
}

public static function int64(System.Platform.BfpFile* file) sBfpFile_GetFileSize;
public static int64 BfpFile_GetFileSize(System.Platform.BfpFile* file)
{
	if (sBfpFile_GetFileSize != null)
		return sBfpFile_GetFileSize(file);
	return System.Platform.BfpFile_GetFileSize(file);
}

public static function int64(System.Platform.BfpFile* file, int64 offset, System.Platform.BfpFileSeekKind seekKind) sBfpFile_Seek;
public static int64 BfpFile_Seek(System.Platform.BfpFile* file, int64 offset, System.Platform.BfpFileSeekKind seekKind)
{
	if (sBfpFile_Seek != null)
		return sBfpFile_Seek(file, offset, seekKind);
	return System.Platform.BfpFile_Seek(file, offset, seekKind);
}

public static function void(System.Platform.BfpFile* file, System.Platform.BfpFileResult* outResult) sBfpFile_Truncate;
public static void BfpFile_Truncate(System.Platform.BfpFile* file, System.Platform.BfpFileResult* outResult)
{
	if (sBfpFile_Truncate != null)
		return sBfpFile_Truncate(file, outResult);
	return System.Platform.BfpFile_Truncate(file, outResult);
}

public static function System.Platform.BfpTimeStamp(char8* path) sBfpFile_GetTime_LastWrite;
public static System.Platform.BfpTimeStamp BfpFile_GetTime_LastWrite(char8* path)
{
	if (sBfpFile_GetTime_LastWrite != null)
		return sBfpFile_GetTime_LastWrite(path);
	return System.Platform.BfpFile_GetTime_LastWrite(path);
}

public static function System.Platform.BfpFileAttributes(char8* path, System.Platform.BfpFileResult* outResult) sBfpFile_GetAttributes;
public static System.Platform.BfpFileAttributes BfpFile_GetAttributes(char8* path, System.Platform.BfpFileResult* outResult)
{
	if (sBfpFile_GetAttributes != null)
		return sBfpFile_GetAttributes(path, outResult);
	return System.Platform.BfpFile_GetAttributes(path, outResult);
}

public static function void(char8* path, System.Platform.BfpFileAttributes attribs, System.Platform.BfpFileResult* outResult) sBfpFile_SetAttributes;
public static void BfpFile_SetAttributes(char8* path, System.Platform.BfpFileAttributes attribs, System.Platform.BfpFileResult* outResult)
{
	if (sBfpFile_SetAttributes != null)
		return sBfpFile_SetAttributes(path, attribs, outResult);
	return System.Platform.BfpFile_SetAttributes(path, attribs, outResult);
}

public static function void(char8* oldPath, char8* newPath, System.Platform.BfpFileCopyKind copyKind, System.Platform.BfpFileResult* outResult) sBfpFile_Copy;
public static void BfpFile_Copy(char8* oldPath, char8* newPath, System.Platform.BfpFileCopyKind copyKind, System.Platform.BfpFileResult* outResult)
{
	if (sBfpFile_Copy != null)
		return sBfpFile_Copy(oldPath, newPath, copyKind, outResult);
	return System.Platform.BfpFile_Copy(oldPath, newPath, copyKind, outResult);
}

public static function void(char8* oldPath, char8* newPath, System.Platform.BfpFileResult* outResult) sBfpFile_Rename;
public static void BfpFile_Rename(char8* oldPath, char8* newPath, System.Platform.BfpFileResult* outResult)
{
	if (sBfpFile_Rename != null)
		return sBfpFile_Rename(oldPath, newPath, outResult);
	return System.Platform.BfpFile_Rename(oldPath, newPath, outResult);
}

public static function void(char8* path, System.Platform.BfpFileResult* outResult) sBfpFile_Delete;
public static void BfpFile_Delete(char8* path, System.Platform.BfpFileResult* outResult)
{
	if (sBfpFile_Delete != null)
		return sBfpFile_Delete(path, outResult);
	return System.Platform.BfpFile_Delete(path, outResult);
}

public static function bool(char8* path) sBfpFile_Exists;
public static bool BfpFile_Exists(char8* path)
{
	if (sBfpFile_Exists != null)
		return sBfpFile_Exists(path);
	return System.Platform.BfpFile_Exists(path);
}

public static function void(char8* outPath, int32* inOutPathSize, System.Platform.BfpFileResult* outResult) sBfpFile_GetTempPath;
public static void BfpFile_GetTempPath(char8* outPath, int32* inOutPathSize, System.Platform.BfpFileResult* outResult)
{
	if (sBfpFile_GetTempPath != null)
		return sBfpFile_GetTempPath(outPath, inOutPathSize, outResult);
	return System.Platform.BfpFile_GetTempPath(outPath, inOutPathSize, outResult);
}

public static function void(char8* outName, int32* inOutNameSize, System.Platform.BfpFileResult* outResult) sBfpFile_GetTempFileName;
public static void BfpFile_GetTempFileName(char8* outName, int32* inOutNameSize, System.Platform.BfpFileResult* outResult)
{
	if (sBfpFile_GetTempFileName != null)
		return sBfpFile_GetTempFileName(outName, inOutNameSize, outResult);
	return System.Platform.BfpFile_GetTempFileName(outName, inOutNameSize, outResult);
}

public static function void(char8* inPath, char8* outPath, int32* inOutPathSize, System.Platform.BfpFileResult* outResult) sBfpFile_GetFullPath;
public static void BfpFile_GetFullPath(char8* inPath, char8* outPath, int32* inOutPathSize, System.Platform.BfpFileResult* outResult)
{
	if (sBfpFile_GetFullPath != null)
		return sBfpFile_GetFullPath(inPath, outPath, inOutPathSize, outResult);
	return System.Platform.BfpFile_GetFullPath(inPath, outPath, inOutPathSize, outResult);
}

public static function void(char8* inPath, char8* outPath, int32* inOutPathSize, System.Platform.BfpFileResult* outResult) sBfpFile_GetActualPath;
public static void BfpFile_GetActualPath(char8* inPath, char8* outPath, int32* inOutPathSize, System.Platform.BfpFileResult* outResult)
{
	if (sBfpFile_GetActualPath != null)
		return sBfpFile_GetActualPath(inPath, outPath, inOutPathSize, outResult);
	return System.Platform.BfpFile_GetActualPath(inPath, outPath, inOutPathSize, outResult);
}

public static function System.Platform.BfpFindFileData*(char8* path, System.Platform.BfpFindFileFlags flags, System.Platform.BfpFileResult* outResult) sBfpFindFileData_FindFirstFile;
public static System.Platform.BfpFindFileData* BfpFindFileData_FindFirstFile(char8* path, System.Platform.BfpFindFileFlags flags, System.Platform.BfpFileResult* outResult)
{
	if (sBfpFindFileData_FindFirstFile != null)
		return sBfpFindFileData_FindFirstFile(path, flags, outResult);
	return System.Platform.BfpFindFileData_FindFirstFile(path, flags, outResult);
}

public static function bool(System.Platform.BfpFindFileData* findData) sBfpFindFileData_FindNextFile;
public static bool BfpFindFileData_FindNextFile(System.Platform.BfpFindFileData* findData)
{
	if (sBfpFindFileData_FindNextFile != null)
		return sBfpFindFileData_FindNextFile(findData);
	return System.Platform.BfpFindFileData_FindNextFile(findData);
}

public static function void(System.Platform.BfpFindFileData* findData, char8* outName, int32* inOutNameSize, System.Platform.BfpFileResult* outResult) sBfpFindFileData_GetFileName;
public static void BfpFindFileData_GetFileName(System.Platform.BfpFindFileData* findData, char8* outName, int32* inOutNameSize, System.Platform.BfpFileResult* outResult)
{
	if (sBfpFindFileData_GetFileName != null)
		return sBfpFindFileData_GetFileName(findData, outName, inOutNameSize, outResult);
	return System.Platform.BfpFindFileData_GetFileName(findData, outName, inOutNameSize, outResult);
}

public static function System.Platform.BfpTimeStamp(System.Platform.BfpFindFileData* findData) sBfpFindFileData_GetTime_LastWrite;
public static System.Platform.BfpTimeStamp BfpFindFileData_GetTime_LastWrite(System.Platform.BfpFindFileData* findData)
{
	if (sBfpFindFileData_GetTime_LastWrite != null)
		return sBfpFindFileData_GetTime_LastWrite(findData);
	return System.Platform.BfpFindFileData_GetTime_LastWrite(findData);
}

public static function System.Platform.BfpTimeStamp(System.Platform.BfpFindFileData* findData) sBfpFindFileData_GetTime_Created;
public static System.Platform.BfpTimeStamp BfpFindFileData_GetTime_Created(System.Platform.BfpFindFileData* findData)
{
	if (sBfpFindFileData_GetTime_Created != null)
		return sBfpFindFileData_GetTime_Created(findData);
	return System.Platform.BfpFindFileData_GetTime_Created(findData);
}

public static function System.Platform.BfpTimeStamp(System.Platform.BfpFindFileData* findData) sBfpFindFileData_GetTime_Access;
public static System.Platform.BfpTimeStamp BfpFindFileData_GetTime_Access(System.Platform.BfpFindFileData* findData)
{
	if (sBfpFindFileData_GetTime_Access != null)
		return sBfpFindFileData_GetTime_Access(findData);
	return System.Platform.BfpFindFileData_GetTime_Access(findData);
}

public static function System.Platform.BfpFileAttributes(System.Platform.BfpFindFileData* findData) sBfpFindFileData_GetFileAttributes;
public static System.Platform.BfpFileAttributes BfpFindFileData_GetFileAttributes(System.Platform.BfpFindFileData* findData)
{
	if (sBfpFindFileData_GetFileAttributes != null)
		return sBfpFindFileData_GetFileAttributes(findData);
	return System.Platform.BfpFindFileData_GetFileAttributes(findData);
}

public static function int64(System.Platform.BfpFindFileData* findData) sBfpFindFileData_GetFileSize;
public static int64 BfpFindFileData_GetFileSize(System.Platform.BfpFindFileData* findData)
{
	if (sBfpFindFileData_GetFileSize != null)
		return sBfpFindFileData_GetFileSize(findData);
	return System.Platform.BfpFindFileData_GetFileSize(findData);
}

public static function void(System.Platform.BfpFindFileData* findData) sBfpFindFileData_Release;
public static void BfpFindFileData_Release(System.Platform.BfpFindFileData* findData)
{
	if (sBfpFindFileData_Release != null)
		return sBfpFindFileData_Release(findData);
	return System.Platform.BfpFindFileData_Release(findData);
}

